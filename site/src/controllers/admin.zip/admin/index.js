module.exports = {
    list: require("./productList.controller.js"),
    barcode: require("./barcode.controller.js"),
    userList: require("./userList.controller.js"),
    userDetail: require("./userDetail.controller.js"),
    userEdit: require("./userEdit.controller.js"),
    create: require("./create.controller.js"),
    store: require("./storeProduct.controller"),
    edit: require("./edit.controller.js"),
    update: require("./update.controller.js"),
    delete: require("./delete.controller.js"),
    destroy: require("./destroy.controller.js"),
    restore: require("./restore.controller.js"),
    orderList: require("./orderList.controller.js"),
    orderDetail: require("./orderDetail.controller.js"),
    downloadOrderPdf: require("./downloadOrderPdf.controller.js"),
    updateOrderState: require("./updateOrderState.controller.js"),
    salesDay: require("./salesDay.controller.js")
  };
